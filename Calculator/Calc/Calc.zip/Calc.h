#pragma once

#ifndef _CALC_CALC_ABACKER_
#define _CALC_CALC_ABACKER_

#include <stack>
#include <cstring>
#include <iostream>

#include "Cache.h"
#include "Symbol.h"
#include "Commen.h"

using namespace std;

Cache cache;
stack<char>OPTR;
stack<double>OPND;

double Calc(string s,bool isCache=true) {
	precondition(s);

	while (!OPTR.empty())OPTR.pop();
	while (!OPND.empty())OPND.pop();

	OPTR.push(endSym());//#

	int size = (int)s.size();
	if (s.back() == '=')--size;

	for (int i = 0; i < size; ++i) {
		if (s[i] == ' ')continue;
		else if (isLtr(s[i])) {//����
			try {
				OPND.push(cache.get(getVar(s, i)));
			}
			catch (...) {
				throw exception("Error:Wrong Expression!");
			}
		}
		else if (isNum(s[i]))OPND.push(getFigure(s, i));//����
		else if (s[i] == ',')while (GetTop(OPTR, false) != '(')Calc(OPTR, OPND);
		else if (s[i] == '(')OPTR.push('(');
		else if (s[i] == ')') {
			while (GetTop(OPTR, false) != '(') {
				Calc(OPTR, OPND);
			}GetTop(OPTR);
		}
		else {//����
			while (Prio(s[i]) <= Prio(GetTop(OPTR, false))) {
				Calc(OPTR, OPND);
			}OPTR.push(s[i]);
		}
	}
	while (GetTop(OPTR, false) != endSym()) {//#
		Calc(OPTR, OPND);
	}

	if (OPTR.size() > 1 || OPND.size() > 1)throw exception("Error:Wrong Expression!");
	if (isCache) { cache.push(GetTop(OPND, false)); cache.printLastPush(); }

	return GetTop(OPND, false);
}

#endif;